
user=$(whoami)

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mBrendan's Install script\e[0m"
echo -e "\e[31m----------------\e[0m"

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mInstalling Yay and the rest of the shit\e[0m"
echo -e "\e[31m-----------------\e[0m"

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mNvidia Drivers + Xorg\e[0m"
echo -e "\e[31m-----------------\e[0m"

sudo pacman -S --noconfirm \
nvidia \
nvidia-settings \
xorg \
xorg-xinit

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mWifi Drivers\e[0m"
echo -e "\e[31m-----------------\e[0m"
sudo pacman -S --noconfirm \
broadcom-wl \
networkmanager-openconnect \
network-manager-applet \
net-tools

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSound Drivers\e[0m"
echo -e "\e[31m-----------------\e[0m"
#Sound Control
sudo pacman -S --noconfirm \
alsa \
pulseaudio \
pavucontrol \
libpulse \


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSystem Tools\e[0m"
echo -e "\e[31m-----------------\e[0m"
#system tools
sudo pacman -S --noconfirm \
htop \
git \
neofetch \
zsh \
base-devel \
terminator \


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mI3 and Polybar\e[0m"
echo -e "\e[31m-----------------\e[0m"
#window manager
sudo pacman -S --noconfirm \
i3 \
jsoncpp \
i3lock \
thunar \
lxappearance \
xautolock \
dmenu \
arc-icon-theme \
arc-gtk-theme \
jq \
udisks2

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mPrograms\e[0m"
echo -e "\e[31m-----------------\e[0m"
#Programs
sudo pacman -S --noconfirm \
vlc \
gimp \
gparted \
firefox \
virtualbox \
notepadqq \
remmina \
freerdp


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSystem Fonts\e[0m"
echo -e "\e[31m-----------------\e[0m"
#fonts
sudo pacman -S --noconfirm \
xorg-fonts-type1 \
gsfonts


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mBluetooth\e[0m"
echo -e "\e[31m-----------------\e[0m"
#bluetooth
sudo pacman -S --noconfirm \
bluez \
blueman

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mEnable Services\e[0m"
echo -e "\e[31m-----------------\e[0m"
echo Setting up base services
systemctl enable NetworkManager
systemctl enable bluetooth


#yay install
git clone https://aur.archlinux.org/yay.git
chown $user:$user ./yay
cd yay
makepkg -si
cd ..

#install yay packages
yay -S \
polybar \
ttf-font-awesome \
adobe-source-code-pro-fonts \
simple-and-soft-cursor \
gpick \
ttf-merriweather-sans \
ttf-opensans \
ttf-oswald \
ttf-quintessential \
ttf-signika \
fonts-meta-extended-lt
ttf-google-fonts-git

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mCopy Config Files\e[0m"
echo -e "\e[31m-----------------\e[0m"
cp -r gtk-3.0 ~/.config/gtk-3.0
cp -r i3 ~/.config/i3
cp -r polybar ~/.config/polybar
cp -r terminator ~/.config/terminator
cp -r /user_folder/. ~/
sudo cp -r etc_profile /etc/profile
sudo cp -r 95-usb.rules /etc/udev/rules.d/95-usb.rules
sudo mkdir /var/run/polybar-system-usb-udev
sudo --user=$user chown $user:$user /var/run/polybar-system-usb-udev








