echo Install yay
#yay install
git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si


#install yay packages
yay -S \
polybar \
ttf-font-awesome \
adobe-source-code-pro-fonts \
simple-and-soft-cursor \
gpick


#fonts
yay -S ttf-merriweather-sans ttf-opensans ttf-oswald ttf-quintessential ttf-signika
yay -S fonts-meta-extended-lt
yay -S ttf-google-fonts-git