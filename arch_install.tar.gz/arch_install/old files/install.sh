#yay install
#git clone https://aur.archlinux.org/yay.git
#cd yay
#makepkg -si

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mBrendan's Install script\e[0m"
echo -e "\e[31m----------------\e[0m"
echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mNvidia Drivers + Xorg\e[0m"
echo -e "\e[31m-----------------\e[0m"

pacman -S --noconfirm \
nvidia \
nvidia-settings \
xorg \
xorg-xinit

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mWifi Drivers\e[0m"
echo -e "\e[31m-----------------\e[0m"
pacman -S --noconfirm \
broadcom-wl \
networkmanager-openconnect \
network-manager-applet \
net-tools

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSound Drivers\e[0m"
echo -e "\e[31m-----------------\e[0m"
#Sound Control
pacman -S --noconfirm \
alsa \
pulseaudio \
pavucontrol \
libpulse \


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSystem Tools\e[0m"
echo -e "\e[31m-----------------\e[0m"
#system tools
pacman -S --noconfirm \
htop \
git \
neofetch \
zsh \
base-devel \
terminator \


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mI3 and Polybar\e[0m"
echo -e "\e[31m-----------------\e[0m"
#window manager
pacman -S --noconfirm \
i3 \
jsoncpp \
i3lock \
thunar \
lxappearance \
xautolock \
dmenu \
arc-icon-theme \
arc-gtk-theme \
jq \
udisks2

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mPrograms\e[0m"
echo -e "\e[31m-----------------\e[0m"
#Programs
pacman -S --noconfirm \
vlc \
gimp \
gparted \
firefox \
virtualbox \
notepadqq \
remmina \
freerdp


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mSystem Fonts\e[0m"
echo -e "\e[31m-----------------\e[0m"
#fonts
pacman -S --noconfirm \
xorg-fonts-type1 \
gsfonts


echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mBluetooth\e[0m"
echo -e "\e[31m-----------------\e[0m"
#bluetooth
pacman -S --noconfirm \
bluez \
blueman

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mEnable Services\e[0m"
echo -e "\e[31m-----------------\e[0m"
echo Setting up base services
systemctl enable NetworkManager
systemctl enable bluetooth

echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mCopy Config Files\e[0m"
echo -e "\e[31m-----------------\e[0m"
cp -r gtk-3.0 ~/.config/gtk-3.0
cp -r i3 ~/.config/i3
cp -r polybar ~/.config/polybar
cp -r terminator ~/.config/terminator
cp -r /user_folder/. ~/
cp -r etc_profile /etc/profile
cp -r 95-usb.rules /etc/udev/rules.d/95-usb.rules
echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31mNow run install-yay.sh without sudo reboot and you should be good\e[0m"
echo -e "\e[31m-----------------\e[0m"
echo -e "\e[31m-----------------\e[0m"




