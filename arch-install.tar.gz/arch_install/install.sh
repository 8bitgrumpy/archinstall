echo install video drivers 
Install yay
#yay install
git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si


# pacman installs
pacman -S \
nvidia \
nvidia-settings\
xorg 

echo installl networking
#Network wifi driver & tools
pacman -S \
broadcom-wl \
networkmanager-openconnect \
network-manager-applet \
nettools

echo install sound drivers
#Sound Control
pacman -S \
alsa \
pulseaudio \
pavucontrol \
libpulse \


echo install system tools
#system tools
pacman -S \
htop \
git \
neofetch \
zsh \
base-devel \
terminator

echo install I3 window manager
#window manager
pacman -S i3 \
jsoncpp \
i3lock \
thunar \
lxappearance \
xautolock \
dmenu \
arc-icon-theme \
arc-gtk-theme \
jq \
udisks2

echo install programs
#Programs
pacman -S \
vlc \
gimp \
gparted \
firefox \
virtualbox \
notepadqq \
remmina \
freerdp

echo fonts 
#fonts
pacman -S \
xorg-fonts-type1 \
gsfonts


echo Setup bluetooth
#bluetooth
pacman -S \
bluez \
blueman

echo Setting up base services
systemctl enable NetworkManager
systemctl enable bluetooth



echo Install yay
#yay install
git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si


