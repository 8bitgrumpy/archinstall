user=$(whoami)
sudo mkdir /var/run/polybar-system-usb-udev
sudo chown $user:$user /var/run/polybar-system-usb-udev
